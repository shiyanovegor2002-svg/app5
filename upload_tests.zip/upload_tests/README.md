# Тестовые файлы для upload-ручек SafeMobile (sb-test.safe-mobile.ru)

Назначение: обход валидации на ручках загрузки файлов.

## Карта ручек и что класть

| Ручка | Каталог | Что проверяем |
|---|---|---|
| `POST /api/v120/files/upload` (обои) | `files_upload/` | type-confusion (SVG/XXE в PNG), polyglot, decompression bomb |
| `POST /api/v81/application/upload` (APK/IPA) | `application_upload/` | zip-slip, plist-XXE, polyglot zip, не-zip |
| `POST /api/v111/kit/upload` | `kit_upload/` | CSV formula, XLSX XXE |
| `POST /api/v111/employee/batch/update/upload` | `employee_batch_upload/` | CSV formula, XLSX XXE |
| `POST /api/v110/letter/attachment/upload` | `letter_attachment/` | SVG/HTML XSS, PE-исполняемый файл |
| `POST /api/v1/cert/upload` / `cert-server/upload` | `cert_upload/` | malformed PEM, DER garbage |
| `POST /api/v130/file-upload` | `file_upload/` | PNG+PHP polyglot (webshell) |
| — (поле `fileName`/`filename` в multipart) | `filenames/traversal_filenames.txt` | path traversal в имени файла |

## Обходы валидации по классам

1. **Path traversal** — `../`, двойное/тройное кодирование `%2e%2e%2f`, `%5c`, overlong UTF-8 `%c0%af`, null-byte `%00`, unicode RTL `\u202e`.
2. **XXE** — `file:///etc/passwd`, `http://`, параметрические сущности, XInclude — в plist (IPA), sheet1.xml (XLSX), SVG.
3. **Zip-slip** — entry `../../tmp/poc`, `../../../../etc/cron.d/poc`.
4. **Polyglot** — PNG+SVG, GIF+JS, ZIP+PNG, PNG+PHP.
5. **Formula injection (CSV/XLSX)** — `=cmd|...`, `+cmd|...`, `-cmd|...`, `@cmd|...`, `=HYPERLINK(...)`.
6. **Type confusion** — расширение/магия не совпадают, MIME подмена.
7. **Decompression bomb** — PNG 100000x100000.

## Как прогонять

- `files/upload`, `letter/attachment/upload`, `file-upload`: multipart `file` + поле `fileName`/`filename` = значение из `filenames/traversal_filenames.txt`.
- `application/upload`, `kit/upload`, `employee/batch/update/upload`, `cert/upload`: multipart `file` = файл из каталога.
- Наблюдение: ответ (500/576/разобранные поля), список файлов/шаблонов, OOB-канарейка (interactsh) для XXE/SSRF, `files/wallpaper` после upload.
